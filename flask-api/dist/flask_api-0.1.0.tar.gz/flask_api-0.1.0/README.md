[//]: # (https://python-poetry.org/docs/basic-usage/)
[//]: # (poetry run flask --app flask_api run)
[//]: # (poetry run pytest)
[//]: # (docker buildx build -t flask-api -f FlaskDockerfile .)
[//]: # (docker run -p 5000:5000 flask-api)

